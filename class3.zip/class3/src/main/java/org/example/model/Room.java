package org.example.model;

public class Room {
    private int roomID;
    private String roomName;
    private String roomEven;
    private long roomStart;
    private long roomEnd;



    public int getRoomID() {
        return roomID;
    }

    public void setRoomID(int roomID) {
        this.roomID = roomID;
    }

    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public String getRoomEven() {
        return roomEven;
    }

    public void setRoomEven(String roomEven) {
        this.roomEven = roomEven;
    }

    public long getRoomStart() {
        return roomStart;
    }

    public void setRoomStart(long roomStart) {
        this.roomStart = roomStart;
    }

    public long getRoomEnd() {
        return roomEnd;
    }

    public void setRoomEnd(long roomEnd) {
        this.roomEnd = roomEnd;
    }
}
